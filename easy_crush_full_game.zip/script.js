let multiplier = 1.00;
let speed = 0;
let countdown = 10;
let interval;
let plane = document.getElementById('plane');
let multiplierDisplay = document.getElementById('multiplier');
let speedDisplay = document.getElementById('speed');
let countdownDisplay = document.getElementById('countdown');
let betBtn = document.getElementById('betBtn');
let cashoutHistory = document.getElementById('historyList');
let dropHistoryIcon = document.getElementById('dropHistory');
let roundHistory = document.getElementById('roundHistory');
let lastRounds = document.getElementById('lastRounds');
let totalBet = document.getElementById('totalBet');
let totalCashOut = document.getElementById('totalCashOut');

let totalBetValue = 0;
let totalCashOutValue = 0;

function resetGame() {
  multiplier = 1.00;
  speed = 0;
  countdown = 10;
  plane.style.left = '0';
  multiplierDisplay.innerText = '1.00x';
  speedDisplay.innerText = '0 km/h';
  countdownDisplay.innerText = countdown;
  betBtn.disabled = false;
  betBtn.innerText = 'BET';
}

function startGame() {
  let multiplierInterval = setInterval(() => {
    multiplier += 0.01;
    speed += 2;
    multiplierDisplay.innerText = multiplier.toFixed(2) + 'x';
    speedDisplay.innerText = speed + ' km/h';
    let currentLeft = parseFloat(plane.style.left) || 0;
    plane.style.left = (currentLeft + 1) + '%';

    if (multiplier >= Math.random() * 5 + 1) {
      clearInterval(multiplierInterval);
      setTimeout(resetGame, 2000);
    }
  }, 100);
}

function startCountdown() {
  interval = setInterval(() => {
    countdown--;
    countdownDisplay.innerText = countdown;
    if (countdown <= 0) {
      clearInterval(interval);
      startGame();
    }
  }, 1000);
}

betBtn.addEventListener('click', () => {
  if (betBtn.innerText === 'BET') {
    let betAmount = parseInt(document.getElementById('betAmount').value);
    totalBetValue += betAmount;
    totalBet.innerText = 'Total Bet: ' + totalBetValue;
    betBtn.innerText = 'CASHOUT';
  } else {
    let betAmount = parseInt(document.getElementById('betAmount').value);
    let cashout = (betAmount * multiplier).toFixed(2);
    totalCashOutValue += parseFloat(cashout);
    totalCashOut.innerText = 'Total Cash-out: ' + totalCashOutValue;
    cashoutHistory.innerHTML += `<div>Cashed out at ${multiplier.toFixed(2)}x: 💸 ${cashout}</div>`;
    lastRounds.innerHTML = `<div>${multiplier.toFixed(2)}x</div>` + lastRounds.innerHTML;
    betBtn.innerText = 'BET';
    betBtn.disabled = true;
  }
});

dropHistoryIcon.addEventListener('click', () => {
  roundHistory.style.display = roundHistory.style.display === 'block' ? 'none' : 'block';
});

resetGame();
startCountdown();
